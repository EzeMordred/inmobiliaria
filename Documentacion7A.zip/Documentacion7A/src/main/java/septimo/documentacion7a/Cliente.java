
package septimo.documentacion7a;

public class Cliente {
    String nombre;
    String apellido;
    char genero;
    int edad; 
}
