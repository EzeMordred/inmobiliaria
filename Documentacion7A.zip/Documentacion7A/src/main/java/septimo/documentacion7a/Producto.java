
package septimo.documentacion7a;

public class Producto {
    String nombre;
    int cantidad; 
    double valor;
    double descuento;

    public Producto(String nombre, int cantidad, double valor, double descuento) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.valor = valor;
        this.descuento = descuento;
    }

    public Producto(String nombre, int cantidad, double valor) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.valor = valor;
    }
    
}
