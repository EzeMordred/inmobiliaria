
package septimo.documentacion7a;

public class Factura {
    String fecha_compra;
    String forma_pago;

    public Factura(String fecha_compra, String forma_pago) {
        this.fecha_compra = fecha_compra;
        this.forma_pago = forma_pago;
    }
    
    public double valor_total (int cantidad, double valor, double descuento){
        return (valor-(valor*descuento))*cantidad;
    }
    
    public double valor_total (int cantidad, double valor){
        return valor*cantidad;
    }
    
    public double valor_individual (int cantidad, double valor) throws ArithmeticException{
        return valor/cantidad;
    }
}
